export class LoginModel {
    email: String;
    password: String;
}
