export class RegisterModel {
    name: String;
    email: String;
    password: String;
}
