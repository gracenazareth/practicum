import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestuarantRegistrtionComponent } from './restuarant-registrtion.component';

describe('RestuarantRegistrtionComponent', () => {
  let component: RestuarantRegistrtionComponent;
  let fixture: ComponentFixture<RestuarantRegistrtionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestuarantRegistrtionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestuarantRegistrtionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
