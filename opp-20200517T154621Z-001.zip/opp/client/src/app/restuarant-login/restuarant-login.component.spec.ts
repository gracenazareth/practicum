import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestuarantLoginComponent } from './restuarant-login.component';

describe('RestuarantLoginComponent', () => {
  let component: RestuarantLoginComponent;
  let fixture: ComponentFixture<RestuarantLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestuarantLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestuarantLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
